


function Contact() {
    return (
        <div className="contact-page">
             
            < img  className="contactimg" src="./Images/contactimg.JPG" />

         
            <section className="contact-content">
               
            <h1 className="contact-us">contact us</h1>
                <section className="contact-part">
                    <div className="contact-icons">
                        <img src="./Images/instagram.JPG" />
                        <img src="./Images/email.JPG" />
                        <img src="./Images/telegram.JPG" />
                    </div>
                    <div className="contact-id">
                        <h3>@alirahemih</h3>
                        <h3>ali.rahemi.t@gmail.com</h3>
                        <h3>ali_rahemi</h3>
                    </div>
                    <div />
                </section>
               
            </section>
        </div>

    );
}

export default Contact;