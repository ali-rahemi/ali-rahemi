


function Works() {

    return (

        <div className="works">
            <div class="container">

                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Images/work1.JPG" alt="image1" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work2.JPG" alt="image2" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work3.JPG" alt="image3" class="img-fluid" />
                    </div>

                    <div class="col-sm-4">
                        <img src="./Images/work10.JPG" alt="image10" class="img-fluid" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Images/work4.JPG" alt="image4" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work5.JPG" alt="image5" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work6.JPG" alt="image6" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work11.JPG" alt="image11" class="img-fluid" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Images/work7.JPG" alt="image7" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work8.JPG" alt="image8" class="img-fluid" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Images/work9.JPG" alt="image9" class="img-fluid" />
                    </div>

                    <div class="col-sm-4">
                        <img src="./Images/work12.JPG" alt="image12" class="img-fluid" />
                    </div>



                </div>
            </div>
        </div>



    );
}

export default Works;