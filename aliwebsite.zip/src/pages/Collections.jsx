

function Collections() {
    return (
        <div className="collection-page">
            <div className="collections">
                <a href="/collection-images">
                    <img className="collection1-img" src="./Images/collection-img.JPG" />
                </a>
                <div className="collection1-texts">
                    <a href="/collection-images">
                        <h1 className="collection1-name">Recycle</h1>
                    </a>
                </div>
            </div>
        </div>
    );
}

export default Collections;