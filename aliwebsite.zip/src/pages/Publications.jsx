

function Publications() {
    return ( 
        <div className="publication-div">
            <img className="publication1" src="./Images/publication1.JPG" />
            <img className="publication1" src="./Images/publication2.JPG" />
        </div>
     );
}

export default Publications;