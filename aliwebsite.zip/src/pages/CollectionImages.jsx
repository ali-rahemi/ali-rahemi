

function CollectionImages() {
    return (


        <div className="collection-images">
            <h1 className="titel-collection">Recycle</h1>
            <h3 className="collection-text">Our subconscious is a black cat in the night. Black cat sometimes in a hole called archetype
                n history, to every corner
                He spends the rest of his time looking for the garbage he finds in the basement
                We have dropped it.
                A long time ago, after some reading about Walter
                Benjamin's thoughts (Benjamin Schönflies Bendix Walter)
                The foundation of the upcoming collection began
                in my brain. Some time later, in the continuation
                of my thoughts, I made a decision one night
                I chased my black cat to the hole he was moving
                towards and the next day by the same
                I followed him and wandered in the desert which
                was in a way the area of both of our lives.
                I will pass through the garbage left in it. I
                rummaged through the discarded garbage for a
                long time.
                I split the plastic bags and poured their contents
                out in front of me. Sometimes my clothes get dirty
                It was smelly and sometimes in the middle of the
                desert I encountered a wall that I did not know behind
                What is! But the result of my adventure among the
                garbage was valuable items that I sometimes see
                he ate. After some time, I decided to take with
                me the things that are worth recycling or reuse
                take home You won't believe what valuable items
                are sometimes found in the desert. sometimes
                Back home, a neighbor found his lost item among
                my valuable trash
                He found it again and admitted that he has been
                looking for it for a long time. Now, after a long time of littering
                I have come to believe that sometimes people don
                't even know what they are throwing away
                They hold things.
                The next collection is a collection of some of our desert recycling.
                Throughout this journey, the black cat was my guide.</h3>
            <div class="container-collection">

                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Collectimages/1.jpg" alt="image1" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/2.jpg" alt="image2" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/3.jpg" alt="image3" class="img-collect" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Collectimages/4.jpg" alt="image4" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/5.jpg" alt="image5" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/6.jpg" alt="image6" class="img-collect" />
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="./Collectimages/7.jpg" alt="image7" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/8.jpg" alt="image8" class="img-collect" />
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/10.jpg" alt="image10" class="img-collect" />
                        
                    </div>
                    <div class="col-sm-4">
                        <img src="./Collectimages/9.jpg" alt="image9" class="img-collect" />
                        
                    </div>



                </div>
            </div>
        </div>

    );
}

export default CollectionImages;