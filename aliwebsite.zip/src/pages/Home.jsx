import Grid from '../components/grid';

function Home() {
    return (<div className='page1'>
        <div>
            <img src='./Images/Wallpaper.jpg' className='wallpaper' />
            {/* <Grid/> */}
        </div>
    </div>);
}

export default Home;