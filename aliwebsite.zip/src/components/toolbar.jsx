


function Toolbar() {
    return (
        <div className="toolbar">
            <a href="/">
            <img   className="signature"  src="./images/signature.svg"/>
            </a>
            <a href="/collections">
            <button >COLLECTIONS</button>
            </a>
            <a  href="/abaut">
            <button >ABAUT</button>
            </a>
            <a   href="/works">
            <button  >WORKS</button>
            </a>
            <a  href="/publications">
            <button >PUBLICATIONS</button>
            </a>
            <a href="/contact">
            <button >CONTACT</button>
            </a>
        </div>
    );


}

export default Toolbar;