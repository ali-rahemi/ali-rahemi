
function Grid() {
    return (

        <div className="grid-container">

            <div className="grid-item-a">a</div>
            <div className="grid-item-b">b</div>
            <div className="grid-item-c">c</div>

        </div>
    );
}

export default Grid;