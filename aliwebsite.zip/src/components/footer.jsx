

function Footer() {
    return ( 
        <div className="footer">
         <h2> ALI RAHEMI HAGHIGHI </h2>
         <h2> COPYRIGHT 2022 |  DESIGHN AND DEVELOPING ALI RAHEMI HAGHIGHI  </h2>
        </div>
     );
}

export default Footer;